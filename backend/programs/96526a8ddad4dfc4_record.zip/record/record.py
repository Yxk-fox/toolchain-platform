#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
矿区数据采集录制脚本 v1.0 —— 单文件图形界面
=====================================================================
本文件已将原 config.yaml / record.sh 三者合并：
  - 配置（必录 Topic、场景、分片/压缩参数、磁盘阈值、目录）内联于 CONFIG 区，
    可直接编辑本文件顶部的 DEFAULT_CONFIG 字典。
  - record.sh 的“自动 source ROS”功能由 ensure_ros_env() 实现：若当前进程
    未 source ROS，则查找 /opt/ros/<distro>/setup.bash 并通过 bash 重新执行
    自身以继承环境变量。

运行：  python3 record.py
依赖：  Python3、PyQt5、PyYAML(可选，缺失时用内置默认配置)、ROS1/ROS2 环境

功能：
  1. 自动识别 ROS 版本（ROS1 noetic / ROS2 humble），未 source 时自动 source
  2. 自动识别 移动硬盘挂载点（可手动选择/浏览），过滤 loop/snap/boot；
     未检测到移动硬盘时自动回退到脚本所在目录，避免误写根目录
  3. 实时探测在线 Topic，按必录清单预勾选；离线必录项置灰告警
  4. 一键启动录制：自动分片、压缩（ROS1/ROS2 均录制原始 bag 后用 tar.zst 压缩；
     ROS2 自动探测 storage，优先 mcap，无 mcap 插件时回退 sqlite3）
     按场景类型+时间戳自动命名，直接写入目标磁盘 data/ 目录
  5. 实时状态监控：已用时、已写入大小
  6. 操作日志写入目标磁盘 logs/，异常告警（磁盘不足、必录项缺失、写权限）
  7. 录制停止后可一键查看 bag 信息摘要
"""

import os
import sys
import re
import json
import time
import signal
import shutil
import subprocess
import importlib
import glob
from datetime import datetime

try:
    from PyQt5.QtCore import Qt, QTimer, QProcess, QUrl
    from PyQt5.QtGui import QFont, QFontDatabase, QColor, QIcon, QDesktopServices
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
        QGroupBox, QLabel, QComboBox, QPushButton, QLineEdit, QSpinBox, QCheckBox,
        QListWidget, QListWidgetItem, QPlainTextEdit, QMessageBox, QFileDialog
    )
    _HAS_PYQT5 = True
except ImportError:
    _HAS_PYQT5 = False


def _bootstrap_deps():
    """PyQt5 等必需依赖缺失时，尝试调用 setup_deps.sh 自动安装，然后重启自身。
    安装策略：先在线(国内源)，无网络则用离线包(packages/)。"""
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    setup_script = os.path.join(_script_dir, "setup_deps.sh")
    print("=" * 60)
    print("[ERROR] 缺少 PyQt5 等必需依赖，无法启动图形界面。")
    print("=" * 60)
    if shutil.which("bash") and os.path.isfile(setup_script):
        print("[INFO] 检测到 setup_deps.sh，尝试自动安装依赖（先在线国内源，无网络则离线包）...")
        rc = subprocess.call(["bash", setup_script, "install"])
        # 验证是否真的装上了
        try:
            importlib.import_module("PyQt5")
            print("[INFO] 依赖安装完成，重新启动脚本...")
            os.execvp(sys.executable, [sys.executable, os.path.abspath(__file__)] + sys.argv[1:])
        except ImportError:
            print("[ERROR] 安装流程结束但仍无法导入 PyQt5，请手动排查。")
            print("[ERROR] 可手动执行:  bash setup_deps.sh install")
    else:
        print("[提示] 在线安装(国内源):")
        print("         pip install PyQt5 PyYAML -i https://pypi.tuna.tsinghua.edu.cn/simple")
        print("[提示] 离线流程:")
        print("         1) 有网络机器执行:  bash setup_deps.sh download")
        print("         2) 拷贝 scripts/ 到离线机后执行:  bash setup_deps.sh install")
    sys.exit(1)

# =====================================================================
# 配置区（原 config.yaml 内容，可直接编辑本字典）
# =====================================================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

DEFAULT_CONFIG = {
    # 必录 Topic 清单（启动时实时探测：在线则预勾选并加粗；离线则置灰告警）
    "required_topics": [
        "/localization/localization_data",
        "/localization/localization_data_rtk",
        "/livox/lidar",
        "/iv_points1",
        "/iv_points2",
        "/rslidar_back",
        "/rslidar_left",
        "/rslidar_right",
        "/pandar_back",
        "/pandar_left",
        "/pandar_right",
        "/camera0",
        "/camera1",
        "/camera2",
        "/camera3",
        "/camera4",
        "/camera5",
        "/camera_back/camera_info",
        "/camera_back/image_raw",
        "/camera_front/camera_info",
        "/camera_front/image_raw",
        "/camera_left/camera_info",
        "/camera_left/image_raw",
        "/camera_right/camera_info",
        "/camera_right/image_raw",
    ],
    # 场景类型预设（下拉框可选，亦可在界面手动输入自定义场景）
    "scene_types": ["装料区", "卸料区", "换电站", "常规路线"],
    # 录制参数
    "record": {
        "ros1": {"split_size_mb": 51200, "compression": "tar.zst"},      # 50GB 分片，录制后 tar.zst 压缩
        "ros2": {"max_bag_size_bytes": 53687091200, "compression": "tar.zst",
                 "storage": "auto",       # auto | mcap | sqlite3，auto 自动探测；录制后 tar.zst 压缩
                 "max_cache_size_bytes": 1073741824},  # 录制缓存 1GB，降低丢帧/磁盘 IO 抖动风险
    },
    # 磁盘
    "disk": {"min_free_gb": 50, "target_size_tb": 4},
    # 目录（logs 目录相对目标挂载点；录制文件直接放在目标挂载点下）
    "paths": {"logs_dir": "logs"},
}

ROS1_DISTROS = {"noetic", "melodic", "kinetic", "lunar"}
ROS2_DISTROS = {"humble", "foxy", "galactic", "iron", "jazzy", "rolling"}


# =====================================================================
# ROS 环境自动 source（替代原 record.sh）
# =====================================================================
def _find_workspace_setup():
    """查找 ROS2 colcon 工作区的 install/setup.bash，返回路径或 None。
    搜索策略（优先级从高到低）：
      0) 环境变量 RECORD_WS_SETUP 直接指定（最高优先级，用户可覆盖）
      1) 从脚本目录向上最多查找 5 层（覆盖脚本放在 <ws>/record/ 或 <ws>/scripts/record/ 等场景）
      2) 额外检查常见工作区位置: ~/ros2_ws, ~/colcon_ws, ~/workspace, ~/robominer_ws，~/robotruck。
    """
    # 策略0: 环境变量 RECORD_WS_SETUP 直接指定
    env_ws = os.environ.get("RECORD_WS_SETUP")
    if env_ws and os.path.isfile(env_ws):
        return env_ws

    # 策略1: 从脚本目录向上查找
    p = SCRIPT_DIR
    for _ in range(5):
        cand = os.path.join(p, "install", "setup.bash")
        if os.path.isfile(cand):
            return cand
        parent = os.path.dirname(p)
        if parent == p:
            break
        p = parent

    # 策略2: 检查常见工作区位置
    home = os.path.expanduser("~")
    candidates = [
        os.path.join(home, "robotruck_ros2", "install", "setup.bash"),
        ##os.path.join(home, "robotruck", "install", "setup.bash"),
    ]
    for cand in candidates:
        if os.path.isfile(cand):
            return cand
    return None


def _print_banner():
    print("=" * 60)
    print(" 矿区数据采集录制 v1.0")
    print(" 脚本目录: %s" % SCRIPT_DIR)
    print(" Python  : %s" % sys.version.split()[0])
    print(" DISPLAY : %s" % (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY") or "(未设置)"))
    custom_setup = os.path.join(SCRIPT_DIR, "setup.bash")
    if os.path.isfile(custom_setup):
        print(" 自定义环境: %s (将自动 source)" % custom_setup)
    else:
        ws = _find_workspace_setup()
        if ws:
            print(" 工作区  : %s (将自动 source)" % ws)
        else:
            print(" 工作区  : 未找到 install/setup.bash")
            print("          方式1: 在脚本目录创建 setup.bash，写入 source /path/to/install/setup.bash")
            print("          方式2: export RECORD_WS_SETUP=/path/to/install/setup.bash")
    print("=" * 60)


def ensure_ros_env():
    """自动 source ROS 系统环境与工作区 install/setup.bash（若需要），然后 re-exec 自身。
    通过环境变量 RECORD_WS_SOURCED 标记已 source 状态，避免重复 re-exec。
    source 顺序：系统 ROS -> 工作区 install/setup.bash -> 脚本目录 setup.bash（用户自定义）"""
    need_ros = not os.environ.get("ROS_DISTRO")
    ws_setup = _find_workspace_setup()
    need_ws = bool(ws_setup) and not os.environ.get("RECORD_WS_SOURCED")
    # 脚本目录下的 setup.bash（用户可自定义 source 任意环境，如 install/setup.bash）
    custom_setup = os.path.join(SCRIPT_DIR, "setup.bash")
    need_custom = os.path.isfile(custom_setup) and not os.environ.get("RECORD_WS_SOURCED")

    if not need_ros and not need_ws and not need_custom:
        return

    parts = []
    # 1) source 系统 ROS（/opt/ros/<distro>/setup.bash）
    if need_ros:
        sourced = False
        for d in ["humble", "iron", "jazzy", "rolling", "foxy", "galactic",
                  "noetic", "melodic", "kinetic", "lunar"]:
            sys_setup = "/opt/ros/%s/setup.bash" % d
            if os.path.isfile(sys_setup):
                parts.append("source '%s'" % sys_setup)
                print("[INFO] 自动 source ROS %s" % d)
                sourced = True
                break
        if not sourced:
            print("[WARN] 未找到已安装的 ROS（/opt/ros/<distro>/setup.bash），请手动 source 后再运行。")
    # 2) source 工作区 install/setup.bash
    if need_ws:
        parts.append("source '%s'" % ws_setup)
        print("[INFO] 自动 source 工作区 %s" % ws_setup)
    # 3) source 脚本目录下的 setup.bash（用户自定义，可 source 任意 install/setup.bash）
    if need_custom:
        parts.append("source '%s'" % custom_setup)
        print("[INFO] 自动 source 自定义环境 %s" % custom_setup)

    if not parts:
        return

    parts.append("export RECORD_WS_SOURCED=1")
    script = os.path.abspath(__file__)
    argv = " ".join('"%s"' % a.replace('"', '\\"') for a in sys.argv[1:])
    parts.append('exec python3 "%s" %s' % (script, argv))
    cmd = " && ".join(parts)
    os.execvp("bash", ["bash", "-c", cmd])


# =====================================================================
# 工具函数
# =====================================================================
def human_size(n):
    """字节数转可读字符串。"""
    n = float(n)
    for u in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024.0:
            return "%.1f %s" % (n, u)
        n /= 1024.0
    return "%.1f PB" % n


def load_config():
    """加载配置。若同目录存在 config.yaml 且 PyYAML 可用则覆盖内置默认值，否则直接用内置配置。
    不安装 PyYAML 也不影响任何核心功能。"""
    cfg = {
        "required_topics": list(DEFAULT_CONFIG["required_topics"]),
        "scene_types": list(DEFAULT_CONFIG["scene_types"]),
        "record": {
            "ros1": dict(DEFAULT_CONFIG["record"]["ros1"]),
            "ros2": dict(DEFAULT_CONFIG["record"]["ros2"]),
        },
        "disk": dict(DEFAULT_CONFIG["disk"]),
        "paths": dict(DEFAULT_CONFIG["paths"]),
    }
    config_path = os.path.join(SCRIPT_DIR, "config.yaml")
    if os.path.isfile(config_path):
        try:
            import yaml
            with open(config_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            for k, v in data.items():
                if k == "record" and isinstance(v, dict):
                    for sub in ("ros1", "ros2"):
                        if sub in v and isinstance(v[sub], dict):
                            cfg["record"][sub].update(v[sub])
                elif isinstance(v, list):
                    cfg[k] = v
                elif isinstance(v, dict):
                    cfg[k] = v
        except ImportError:
            pass  # PyYAML 未安装，静默跳过外部配置
        except Exception as e:
            print("[WARN] 读取 config.yaml 失败：%s，使用内置默认配置。" % e)
    return cfg


def detect_ros():
    """返回 (ROS版本字符串, distro)。无法识别返回 (None, '')。"""
    ver = os.environ.get("ROS_VERSION")
    distro = os.environ.get("ROS_DISTRO", "")
    if ver == "1" or distro in ROS1_DISTROS:
        return ("ROS1", distro or "unknown")
    if ver == "2" or distro in ROS2_DISTROS:
        return ("ROS2", distro or "unknown")
    return (None, "")


def run_cmd(args, timeout=10):
    """运行命令，返回 (returncode, stdout, stderr)。超时返回 (-1, '', msg)。"""
    try:
        p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=timeout, universal_newlines=True)
        return (p.returncode, p.stdout, p.stderr)
    except FileNotFoundError:
        return (127, "", "命令未找到：%s" % args[0])
    except subprocess.TimeoutExpired:
        return (-1, "", "命令执行超时")
    except Exception as e:
        return (1, "", str(e))


def detect_disks(target_tb=4):
    """检测挂载的可写分区，返回 list[dict(name,size,mount,fstype,label,type)]。
    过滤 loop 设备与 /snap、/boot、根目录 /。标记 best=True 给最接近 target_tb 的项。
    若无任何外接磁盘，返回空列表（调用方负责回退到脚本所在目录）。"""
    rc, out, err = run_cmd(
        ["lsblk", "-J", "-b", "-o", "NAME,SIZE,MOUNTPOINT,FSTYPE,LABEL,TYPE"])
    disks = []
    if rc == 0 and out:
        try:
            data = json.loads(out)
            for dev in data.get("blockdevices", []):
                _walk_lsblk(dev, disks)
        except Exception:
            pass
    mounted = []
    for d in disks:
        m = d["mount"]
        if not m:
            continue
        if d.get("type") == "loop":
            continue
        if m == "/" or m.startswith("/snap/") or m.startswith("/boot"):
            continue
        # 仅保留常见可写分区类型/设备（USB 通常是 /media/ 或 /mnt/）
        # 但不强制要求路径前缀，允许 /home 下的 nvme/SSD 也能选中
        mounted.append(d)
    target_bytes = target_tb * 1024 ** 4
    best = None
    best_diff = None
    for d in mounted:
        diff = abs(d["size"] - target_bytes)
        if best_diff is None or diff < best_diff:
            best_diff = diff
            best = d
    if best:
        best["best"] = True
    return mounted


def _walk_lsblk(node, out):
    """递归解析 lsblk JSON 节点。"""
    if node.get("mountpoint"):
        out.append({
            "name": node.get("name", ""),
            "size": int(node.get("size", 0) or 0),
            "mount": node["mountpoint"],
            "fstype": node.get("fstype") or "",
            "label": node.get("label") or "",
            "type": node.get("type") or "",
            "best": False,
        })
    for child in node.get("children", []) or []:
        _walk_lsblk(child, out)


def free_space_gb(path):
    """返回 path 所在分区可用空间(GB)，失败返回 None。"""
    try:
        st = os.statvfs(path)
        return st.f_bavail * st.f_frsize / 1024 ** 3
    except Exception:
        return None


def is_path_writable(path):
    """检查 path 目录是否可写（创建则尝试创建后再检查）。返回 bool。"""
    try:
        os.makedirs(path, exist_ok=True)
        return os.access(path, os.W_OK)
    except Exception:
        return False


def detect_ros2_storage():
    """探测当前 ROS2 环境可用的 bag storage 插件。
    返回 ('mcap', None) 或 ('sqlite3', None)。优先 mcap，否则回退 sqlite3。
    压缩统一由录制结束后的 tar.zst 完成，此处仅决定 storage 格式。"""
    # 方法：执行 ros2 bag record -s mcap --help 看是否报错
    rc, _, _ = run_cmd(["ros2", "bag", "record", "-s", "mcap", "--help"], timeout=8)
    if rc == 0:
        return ("mcap", None)
    return ("sqlite3", None)


def detect_topics(ros_ver):
    """返回在线 topic 列表(set)。"""
    if ros_ver == "ROS1":
        rc, out, _ = run_cmd(["rostopic", "list"], timeout=10)
    elif ros_ver == "ROS2":
        rc, out, _ = run_cmd(["ros2", "topic", "list"], timeout=15)
    else:
        return set()
    if rc != 0:
        return set()
    return {ln.strip() for ln in out.splitlines() if ln.strip()}


def detect_topic_types(ros_ver, topics):
    """检测每个 topic 的消息类型是否在本地可解析。
    返回 dict: topic -> bool  (True=类型可用, False=类型未知/包未 source)。
    ROS1: 用 `rostopic info` 检查 Type 字段是否存在；
    ROS2: 用 `ros2 topic info -v` 检查是否输出 'Type:' 且不含 'unknown type' 错误。
    仅对必录/已选少量 topic 调用，避免批量探测开销过大。"""
    result = {}
    if ros_ver == "ROS1":
        for t in topics:
            rc, out, _ = run_cmd(["rostopic", "info", t], timeout=5)
            has_type = bool(re.search(r"Type:\s+\S+", out))
            result[t] = has_type
    elif ros_ver == "ROS2":
        for t in topics:
            rc, out, err = run_cmd(["ros2", "topic", "info", "-v", t], timeout=8)
            combined = (out + err).lower()
            # ros2 topic info -v 若类型未知会输出: "unknown type" 或 "Could not load"
            # 正常则包含 "Type: <pkg>/msg/<Type>" 且无 unknown/could not 字样
            has_type = ("type:" in combined and
                        "unknown type" not in combined and
                        "could not" not in combined and
                        rc == 0)
            result[t] = has_type
    else:
        for t in topics:
            result[t] = True
    return result


# =====================================================================
# 主窗口
# =====================================================================
class MainWindow(QMainWindow):
    def __init__(self, config):
        super().__init__()
        self.cfg = config
        self.ros_ver, self.ros_distro = detect_ros()
        self.ros2_storage = detect_ros2_storage() if self.ros_ver == "ROS2" else (None, None)
        self.disks = []
        self.live_topics = set()
        self.type_unknown = set()
        self.proc = None              # QProcess 录制进程
        self.zip_proc = None          # 兼容旧引用（已弃用，改用 zip_jobs）
        self.zip_jobs = []            # 后台压缩任务列表，每项 {"proc","session"}，异步执行不影响新录制
        self.session = None           # 当前录制会话信息 dict（压缩不再占用此字段）
        self.stats_timer = QTimer(self)
        self.stats_timer.timeout.connect(self._update_stats)
        self.stop_watchdog = QTimer(self)
        self.stop_watchdog.setSingleShot(True)
        self.stop_watchdog.timeout.connect(self._force_kill)
        self.log_fp = None
        self._init_ui()
        self._refresh_environment()
        self._refresh_topics()

    # ---------------- UI 构建 ----------------
    def _init_ui(self):
        self._setup_chinese_font()
        self.setWindowTitle("矿区数据采集录制 v1.0")
        self.resize(1280, 820)

        root = QWidget()
        self.setCentralWidget(root)
        lay = QHBoxLayout(root)
        lay.setSpacing(10)

        # --- 环境区 ---
        gb_env = QGroupBox("环境检测")
        f_env = QFormLayout(gb_env)
        f_env.setLabelAlignment(Qt.AlignRight)

        self.lbl_ros = QLabel("检测中…")
        self.lbl_ros.setStyleSheet("font-weight:bold;")
        self.disk_combo = QComboBox()
        self.disk_combo.setMinimumWidth(360)
        self.btn_refresh_disk = QPushButton("刷新")
        self.btn_refresh_disk.clicked.connect(self._refresh_disks)
        self.btn_browse = QPushButton("浏览…")
        self.btn_browse.clicked.connect(self._browse_disk)
        self.lbl_free = QLabel("—")
        self.lbl_free.setStyleSheet("font-weight:bold;")

        disk_row = QHBoxLayout()
        disk_row.addWidget(self.disk_combo)
        disk_row.addWidget(self.btn_refresh_disk)
        disk_row.addWidget(self.btn_browse)
        f_env.addRow("ROS 版本：", self.lbl_ros)
        f_env.addRow("移动硬盘：", disk_row)
        f_env.addRow("可用空间：", self.lbl_free)

        # --- 采集参数区 ---
        gb_param = QGroupBox("采集参数")
        f_param = QFormLayout(gb_param)
        f_param.setLabelAlignment(Qt.AlignRight)

        self.scene_combo = QComboBox()
        self.scene_combo.setEditable(True)
        for s in self.cfg.get("scene_types", []):
            self.scene_combo.addItem(s)
        self.split_spin = QSpinBox()
        self.split_spin.setRange(1, 200000)
        self.split_spin.setSuffix(" MB")
        self.lbl_split_ros2 = QLabel()
        self.chk_compress = QCheckBox("启用压缩")
        self.chk_compress.setChecked(True)
        self.lbl_compress_hint = QLabel()
        self.lbl_compress_hint.setStyleSheet("color:#666;")
        self.out_edit = QLineEdit()
        self.out_edit.setReadOnly(True)

        f_param.addRow("场景类型：", self.scene_combo)
        f_param.addRow("分片大小(ROS1)：", self._hbox(self.split_spin, self.lbl_split_ros2))
        f_param.addRow("压缩：", self._hbox(self.chk_compress, self.lbl_compress_hint))
        f_param.addRow("输出目录：", self.out_edit)

        # --- Topic 区 ---
        gb_topic = QGroupBox("Topic 列表（实时探测 · 必录项预勾选）")
        tv = QVBoxLayout(gb_topic)

        bar = QHBoxLayout()
        self.filter_edit = QLineEdit()
        self.filter_edit.setPlaceholderText("过滤 topic…")
        self.filter_edit.textChanged.connect(self._apply_filter)
        self.btn_sel_required = QPushButton("勾选必录")
        self.btn_sel_required.clicked.connect(self._select_required)
        self.btn_sel_all = QPushButton("全选")
        self.btn_sel_all.clicked.connect(lambda: self._set_all_check(True))
        self.btn_sel_none = QPushButton("全不选")
        self.btn_sel_none.clicked.connect(lambda: self._set_all_check(False))
        self.btn_refresh_topic = QPushButton("刷新Topic")
        self.btn_refresh_topic.clicked.connect(self._refresh_topics)
        bar.addWidget(QLabel("过滤："))
        bar.addWidget(self.filter_edit, 1)
        bar.addWidget(self.btn_sel_required)
        bar.addWidget(self.btn_sel_all)
        bar.addWidget(self.btn_sel_none)
        bar.addWidget(self.btn_refresh_topic)
        tv.addLayout(bar)

        self.topic_list = QListWidget()
        self.topic_list.setAlternatingRowColors(True)
        self.topic_list.setMinimumWidth(420)
        tv.addWidget(self.topic_list)

        self.lbl_topic_stat = QLabel()
        self.lbl_topic_stat.setStyleSheet("font-weight:bold;")
        tv.addWidget(self.lbl_topic_stat)

        # --- 控制与状态区 ---
        gb_ctrl = QGroupBox("录制控制 / 状态")
        cv = QVBoxLayout(gb_ctrl)

        btn_row = QHBoxLayout()
        self.btn_start = QPushButton("▶ 开始录制")
        self.btn_start.setStyleSheet("font-weight:bold; padding:6px 16px;")
        self.btn_start.clicked.connect(self._start_recording)
        self.btn_stop = QPushButton("■ 停止录制")
        self.btn_stop.setEnabled(False)
        self.btn_stop.setStyleSheet("padding:6px 16px;")
        self.btn_stop.clicked.connect(self._stop_recording)
        self.btn_open_data = QPushButton("打开数据目录")
        self.btn_open_data.clicked.connect(self._open_data)
        self.btn_open_log = QPushButton("查看日志")
        self.btn_open_log.clicked.connect(self._open_log)
        btn_row.addWidget(self.btn_start)
        btn_row.addWidget(self.btn_stop)
        btn_row.addStretch(1)
        btn_row.addWidget(self.btn_open_data)
        btn_row.addWidget(self.btn_open_log)
        cv.addLayout(btn_row)

        stat_row = QHBoxLayout()
        self.lbl_elapsed = QLabel("已用时：00:00:00")
        self.lbl_written = QLabel("已写入：0 B")
        self.lbl_status = QLabel("● 空闲")
        self.lbl_status.setStyleSheet("color:#888; font-weight:bold;")
        for w in (self.lbl_elapsed, self.lbl_written):
            w.setStyleSheet("font-weight:bold;")
        stat_row.addWidget(self.lbl_elapsed)
        stat_row.addWidget(self.lbl_written)
        stat_row.addStretch(1)
        stat_row.addWidget(self.lbl_status)
        cv.addLayout(stat_row)

        # --- 日志区 ---
        gb_log = QGroupBox("运行日志")
        lv = QVBoxLayout(gb_log)
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumBlockCount(5000)
        mono = QFont("Monospace")
        mono.setStyleHint(QFont.TypeWriter)
        self.log_view.setFont(mono)
        lv.addWidget(self.log_view)

        # 右侧垂直布局：环境 + 参数 + 控制 + 日志
        right_panel = QVBoxLayout()
        right_panel.setSpacing(10)
        right_panel.addWidget(gb_env)
        right_panel.addWidget(gb_param, 1)
        right_panel.addWidget(gb_ctrl)
        right_panel.addWidget(gb_log, 2)

        # 主水平布局：左侧 Topic 面板，右侧其他面板
        lay.addWidget(gb_topic, 3)
        lay.addLayout(right_panel, 2)

        self._log("程序启动。脚本目录：%s" % SCRIPT_DIR)

    def _setup_chinese_font(self):
        """为 QApplication 设置支持中文的字体，避免中文显示为方块/乱码。
        优先级：用户可能安装的中文字体（SimHei/微软雅黑）→ 系统常见字体（Noto/WenQuanYi/AR PL）。"""
        candidates = [
            "SimHei", "Microsoft YaHei", "Microsoft YaHei UI", "PingFang SC",
            "Noto Sans CJK SC", "Noto Serif CJK SC", "Noto Sans CJK JP",
            "WenQuanYi Micro Hei", "WenQuanYi Zen Hei", "AR PL UMing CN",
            "AR PL UKai CN", "Droid Sans Fallback",
        ]
        db = QFontDatabase()
        families = set(db.families())
        chosen = None
        for name in candidates:
            if name in families:
                chosen = name
                break
        if chosen:
            font = QFont(chosen, 10)
            QApplication.setFont(font)
            self.setFont(font)

    def _hbox(self, *widgets):
        h = QHBoxLayout()
        for w in widgets:
            h.addWidget(w)
        h.addStretch(1)
        return h

    # ---------------- 环境刷新 ----------------
    def _refresh_environment(self):
        self._refresh_ros()
        self._refresh_disks()

    def _refresh_ros(self):
        if self.ros_ver:
            self.lbl_ros.setText("%s  (%s)" % (self.ros_ver, self.ros_distro))
            self.lbl_ros.setStyleSheet("font-weight:bold; color:#1a7f37;")
        else:
            self.lbl_ros.setText("未检测到 ROS（请 source /opt/ros/<distro>/setup.bash 后再启动）")
            self.lbl_ros.setStyleSheet("font-weight:bold; color:#d73a49;")
        # 根据版本调整参数控件
        if self.ros_ver == "ROS1":
            self.split_spin.setValue(self.cfg["record"]["ros1"]["split_size_mb"])
            self.lbl_split_ros2.setText("")
            self.split_spin.setEnabled(True)
            comp = self.cfg["record"]["ros1"]["compression"]
            self.chk_compress.setChecked(comp != "none")
            self.lbl_compress_hint.setText("(ROS1: 录制结束后 tar.zst 压缩)")
        elif self.ros_ver == "ROS2":
            self.lbl_split_ros2.setText("ROS2 固定 %.0f GB/分片" %
                                        (self.cfg["record"]["ros2"]["max_bag_size_bytes"] / 1024 ** 3))
            self.split_spin.setEnabled(False)
            comp = self.cfg["record"]["ros2"]["compression"]
            self.chk_compress.setChecked(comp != "none")
            stg = self.ros2_storage[0] if self.ros2_storage[0] else "sqlite3"
            self.lbl_compress_hint.setText("(ROS2: %s, 录制结束后 tar.zst 压缩)" % stg)
        else:
            self.lbl_split_ros2.setText("")
            self.lbl_compress_hint.setText("")

    def _refresh_disks(self):
        target_tb = self.cfg["disk"].get("target_size_tb", 4)
        self.disks = detect_disks(target_tb)

        # 始终把"脚本所在目录"作为可写回退项（避免未插4T盘时误选根目录）
        try:
            script_stat = os.statvfs(SCRIPT_DIR)
            script_size = script_stat.f_blocks * script_stat.f_frsize
        except Exception:
            script_size = 0
        fallback = {"name": "(脚本目录)", "size": script_size, "mount": SCRIPT_DIR,
                    "fstype": "", "label": "脚本目录(回退)", "fallback": True}

        self.disk_combo.blockSignals(True)
        self.disk_combo.clear()
        idx_best = 0
        # 先加外接盘
        for i, d in enumerate(self.disks):
            label = "%s  (%s, %s, %s)" % (
                d["mount"], d["name"], human_size(d["size"]),
                d["label"] or d["fstype"] or "-")
            self.disk_combo.addItem(label, d)
            if d.get("best"):
                idx_best = i
        # 再加回退目录
        fb_label = "%s  (脚本目录，回退)" % SCRIPT_DIR
        self.disk_combo.addItem(fb_label, fallback)
        fb_idx = self.disk_combo.count() - 1
        self.disks.append(fallback)

        if any(d.get("best") for d in self.disks):
            self.disk_combo.setCurrentIndex(idx_best)
        else:
            # 无外接盘，默认选脚本目录
            self.disk_combo.setCurrentIndex(fb_idx)
        self.disk_combo.blockSignals(False)
        self._on_disk_changed()
        if not any(not d.get("fallback") for d in self.disks):
            self._log("[提示] 未检测到 移动硬盘，将使用脚本所在目录作为输出位置。")

    def _browse_disk(self):
        d = QFileDialog.getExistingDirectory(self, "选择移动硬盘挂载目录（或任意可写数据目录）")
        if d:
            # 作为自定义项加入
            custom = {"name": "(自定义)", "size": 0, "mount": d,
                      "fstype": "", "label": "自定义", "best": True}
            self.disks.insert(0, custom)
            self.disk_combo.blockSignals(True)
            self.disk_combo.insertItem(0, "%s  (自定义目录)" % d, custom)
            self.disk_combo.setCurrentIndex(0)
            self.disk_combo.blockSignals(False)
            self._on_disk_changed()

    def _on_disk_changed(self):
        d = self.disk_combo.currentData()
        if not d:
            self.lbl_free.setText("—")
            self.out_edit.clear()
            return
        mount = d["mount"]
        # 可写性预检查
        writable = is_path_writable(mount)
        if not writable:
            self._log("[告警] 目录 %s 无写入权限，尝试自动回退到脚本所在目录。" % mount)
            # 找到脚本目录那一项并切换
            for i in range(self.disk_combo.count()):
                dd = self.disk_combo.itemData(i)
                if dd and dd.get("fallback"):
                    self.disk_combo.setCurrentIndex(i)
                    return
        free = free_space_gb(mount)
        self.lbl_free.setText("%.1f GB" % free if free is not None else "未知")
        self.lbl_free.setStyleSheet(
            "font-weight:bold; color:#1a7f37;" if free and free >= self.cfg["disk"]["min_free_gb"]
            else "font-weight:bold; color:#d73a49;")
        self._update_output_dir()

    def _current_mount(self):
        d = self.disk_combo.currentData()
        return d["mount"] if d else None

    def _update_output_dir(self):
        m = self._current_mount()
        if not m:
            self.out_edit.clear()
            return
        # 录制文件直接放在目标目录下（不再有 data/子目录）
        self.out_edit.setText(m)

    # ---------------- Topic 刷新 ----------------
    def _refresh_topics(self):
        self.btn_refresh_topic.setEnabled(False)
        self._log("正在探测在线 Topic …")
        QApplication.processEvents()
        self.live_topics = detect_topics(self.ros_ver) if self.ros_ver else set()
        # 对在线的必录 topic 检测类型是否在本地可解析（rosbag 能否录制）
        self.type_unknown = set()
        if self.ros_ver and self.live_topics:
            required_set = set(self.cfg.get("required_topics", []))
            to_check = [t for t in self.live_topics if t in required_set]
            if to_check:
                self._log("正在检测必录 Topic 消息类型可用性 …")
                QApplication.processEvents()
                type_map = detect_topic_types(self.ros_ver, to_check)
                for t, ok in type_map.items():
                    if not ok:
                        self.type_unknown.add(t)
                if self.type_unknown:
                    self._log("[告警] %d 个必录 Topic 在线但消息类型包未 source（rosbag 无法录制）：%s"
                              % (len(self.type_unknown), ", ".join(sorted(self.type_unknown))))
                    self._log("       请 source 对应工作区 install/setup.bash 后点“刷新Topic”。")
        self._populate_topics()
        self.btn_refresh_topic.setEnabled(True)
        if not self.ros_ver:
            self._log("[告警] 未检测到 ROS，无法探测 Topic。请 source ROS 环境后点“刷新Topic”。")
        elif not self.live_topics:
            self._log("[告警] 未探测到任何在线 Topic（ROS master/daemon 是否启动？）。")
            # 输出环境诊断信息
            self._log("[诊断] ROS_DISTRO=%s  ROS_VERSION=%s  AMENT_PREFIX_PATH=%s"
                      % (os.environ.get("ROS_DISTRO", "(未设置)"),
                         os.environ.get("ROS_VERSION", "(未设置)"),
                         os.environ.get("AMENT_PREFIX_PATH", "(未设置)")[:200]))
            ws = _find_workspace_setup()
            self._log("[诊断] 工作区 install/setup.bash: %s"
                      % (ws if ws else "未找到（topic 无法被发现，请 source 工作区）"))
            if self.ros_ver == "ROS2":
                self._log("[提示] ROS2 请确认: 1) ros2 daemon 已启动 (ros2 daemon start); "
                          "2) 工作区已 source; 3) 节点正在运行。")
            elif self.ros_ver == "ROS1":
                self._log("[提示] ROS1 请确认: 1) roscore 已启动; 2) 节点正在运行。")

    def _populate_topics(self):
        self.topic_list.clear()
        required = list(self.cfg.get("required_topics", []))
        required_set = set(required)
        type_unknown = getattr(self, "type_unknown", set())

        # 合并：必录项（保持配置顺序）+ 其余在线项（排序）
        all_topics = []
        for t in required:
            all_topics.append(t)
        for t in sorted(self.live_topics - required_set):
            all_topics.append(t)

        # 去重保序
        seen = set()
        ordered = []
        for t in all_topics:
            if t not in seen:
                seen.add(t)
                ordered.append(t)

        for t in ordered:
            online = t in self.live_topics
            type_bad = t in type_unknown
            is_req = t in required_set
            item = QListWidgetItem(t)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            if online and not type_bad:
                # 在线且类型可用：必录预勾选，非必录未勾选
                item.setCheckState(Qt.Checked if is_req else Qt.Unchecked)
            elif online and type_bad:
                # 在线但类型未知（包未 source）：禁用勾选，橙色告警
                item.setCheckState(Qt.Unchecked)
                item.setFlags((item.flags() | Qt.ItemIsUserCheckable) &
                              ~Qt.ItemIsEnabled & ~Qt.ItemIsUserCheckable)
            else:
                # 离线必录项：不可勾选，红色告警
                item.setCheckState(Qt.Unchecked)
                item.setFlags((item.flags() | Qt.ItemIsUserCheckable) &
                              ~Qt.ItemIsEnabled & ~Qt.ItemIsUserCheckable)
            # 外观
            f = item.font()
            if is_req and online and not type_bad:
                f.setBold(True)
                item.setForeground(QColor("#1a7f37"))
                item.setText("%s   ★必录" % t)
            elif is_req and online and type_bad:
                f.setBold(True)
                item.setForeground(QColor("#b58105"))
                item.setText("%s   ⚠类型未知(包未source)" % t)
            elif is_req and not online:
                f.setBold(True)
                item.setForeground(QColor("#d73a49"))
                item.setText("%s   ✗离线(必录缺失)" % t)
            else:
                item.setForeground(QColor("#444"))
            item.setFont(f)
            item.setData(Qt.UserRole, t)
            # UserRole+1 仅标记真正可录制的在线项（排除类型未知）
            item.setData(Qt.UserRole + 1, online and not type_bad)
            self.topic_list.addItem(item)
        self._apply_filter()
        self._update_topic_stat()

    def _apply_filter(self):
        kw = self.filter_edit.text().strip().lower()
        for i in range(self.topic_list.count()):
            item = self.topic_list.item(i)
            item.setHidden(kw != "" and kw not in item.data(Qt.UserRole).lower())

    def _select_required(self):
        for i in range(self.topic_list.count()):
            item = self.topic_list.item(i)
            # 仅对启用且可勾选的在线项操作
            if (item.flags() & Qt.ItemIsEnabled) and (item.flags() & Qt.ItemIsUserCheckable):
                # 必录项（文本含 ★）勾选
                if "★必录" in item.text():
                    item.setCheckState(Qt.Checked)
        self._update_topic_stat()

    def _set_all_check(self, state):
        for i in range(self.topic_list.count()):
            item = self.topic_list.item(i)
            # 仅对启用且可勾选的在线项操作（跳过离线禁用项）
            if (item.flags() & Qt.ItemIsEnabled) and (item.flags() & Qt.ItemIsUserCheckable):
                item.setCheckState(Qt.Checked if state else Qt.Unchecked)
        self._update_topic_stat()

    def _update_topic_stat(self):
        total = self.topic_list.count()
        online_ok = sum(1 for i in range(total)
                        if self.topic_list.item(i).data(Qt.UserRole + 1))
        selected = sum(1 for i in range(total)
                       if self.topic_list.item(i).checkState() == Qt.Checked)
        missing = sum(1 for i in range(total)
                      if "必录缺失" in self.topic_list.item(i).text())
        type_bad = sum(1 for i in range(total)
                       if "类型未知" in self.topic_list.item(i).text())
        parts = ["已选 %d" % selected, "在线可录 %d" % online_ok]
        if type_bad:
            parts.append("类型未知 %d" % type_bad)
        if missing:
            parts.append("必录离线缺失 %d" % missing)
        self.lbl_topic_stat.setText("   |   ".join(parts))
        if missing or type_bad:
            self.lbl_topic_stat.setStyleSheet("font-weight:bold; color:#d73a49;")
        else:
            self.lbl_topic_stat.setStyleSheet("font-weight:bold; color:#1a7f37;")

    def selected_topics(self):
        return [self.topic_list.item(i).data(Qt.UserRole)
                for i in range(self.topic_list.count())
                if self.topic_list.item(i).checkState() == Qt.Checked]

    # ---------------- 录制控制 ----------------
    def _start_recording(self):
        if self.proc is not None:
            return
        # 前置检查
        if not self.ros_ver:
            QMessageBox.critical(self, "无法录制", "未检测到 ROS 环境，请先 source ROS 后重启本程序。")
            return
        mount = self._current_mount()
        if not mount or not os.path.isdir(mount):
            QMessageBox.critical(self, "无法录制", "请选择有效的移动硬盘挂载目录。")
            return
        free = free_space_gb(mount)
        if free is not None and free < self.cfg["disk"]["min_free_gb"]:
            QMessageBox.critical(self, "空间不足",
                                 "可用空间仅 %.1f GB，低于阈值 %d GB，请清理磁盘后重试。"
                                 % (free, self.cfg["disk"]["min_free_gb"]))
            return
        topics = self.selected_topics()
        if not topics:
            QMessageBox.critical(self, "无法录制", "请至少勾选一个在线 Topic。")
            return

        # 检查选中 topic 中是否有类型未知（消息包未 source）的必录项
        type_unknown = getattr(self, "type_unknown", set())
        selected_type_bad = [t for t in topics if t in type_unknown]
        if selected_type_bad:
            # selected_topics 只返回勾选的，但类型未知项已被禁用无法勾选——
            # 理论上不会到达这里，做兜底检查以防用户手动勾选非必录的类型未知项。
            self._log("[告警] 以下选中 Topic 消息类型未知（rosbag 将无法录制其数据）：%s"
                      % ", ".join(selected_type_bad))

        # 告警：有必录项离线或类型未知
        missing_required = [t for t in self.cfg.get("required_topics", [])
                            if t not in self.live_topics or t in type_unknown]
        # 仅提示离线缺失的（类型未知的已在刷新时日志告警了）
        offline_required = [t for t in missing_required if t not in self.live_topics]
        if offline_required:
            ret = QMessageBox.warning(self, "必录 Topic 缺失",
                "以下必录 Topic 当前离线，录制的数据将缺少这些传感器数据：\n\n"
                "  %s\n\n"
                "建议：确认对应驱动/节点已启动后点「刷新Topic」再开始录制。\n"
                "是否仍然继续录制？" % "\n  ".join(offline_required),
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ret != QMessageBox.Yes:
                return

        scene = self.scene_combo.currentText().strip() or "未命名"
        # 简单清洗文件名非法字符
        scene_safe = re.sub(r'[\\/:*?"<>|]', "_", scene)
        date = datetime.now().strftime("%Y%m%d")
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        basename = "%s_%s" % (scene_safe, ts)
        # 录制文件直接放在目标目录下（不再有 data/日期_场景/ 子目录）
        scene_dir = mount
        logs_dir = os.path.join(mount, self.cfg["paths"]["logs_dir"])

        # 前置权限检查：根目录直接拒绝；其他目录用 is_path_writable 探测可写性
        if mount == "/":
            QMessageBox.critical(self, "无法录制",
                "目标目录是系统根目录 /，没有写权限。\n请在上方下拉框选择一个可写目录（如移动硬盘或脚本所在目录），或点“浏览…”手动选择。")
            return
        # 探测目录可写性
        if not is_path_writable(scene_dir) or not is_path_writable(logs_dir):
            QMessageBox.critical(self, "无法录制",
                "目标目录无写入权限：\n  %s\n请选择其他目录后重试。" % mount)
            return

        try:
            os.makedirs(scene_dir, exist_ok=True)
            os.makedirs(logs_dir, exist_ok=True)
        except PermissionError as e:
            QMessageBox.critical(self, "无法录制",
                "创建输出目录被拒绝（权限不足）：%s\n\n建议：\n  1) 选择移动硬盘或脚本所在目录；\n  2) 或在终端用 sudo 启动（注意 ROS 环境需在 root 下也能找到）。" % e)
            return
        except Exception as e:
            QMessageBox.critical(self, "无法录制", "创建输出目录失败：%s" % e)
            return

        # 日志文件：按日期命名
        log_path = os.path.join(logs_dir, "record_%s.log" % date)
        try:
            self.log_fp = open(log_path, "a", encoding="utf-8")
        except Exception as e:
            QMessageBox.warning(self, "日志", "无法打开日志文件：%s" % e)
            self.log_fp = None

        # 构造命令行参数
        compress = self.chk_compress.isChecked()
        if self.ros_ver == "ROS1":
            # ROS1: 录制为 .bag（不使用 bzip2 -j），录制结束后用 tar.zst 压缩
            args = ["rosbag", "record", "-o", basename, "--split",
                    "--size=%d" % self.split_spin.value()]
            args += topics
            program = "rosbag"
        else:  # ROS2
            # ROS2: 录制为 bag 目录（mcap/sqlite3），录制结束后用 tar.zst 压缩
            stg_name = self.ros2_storage[0] if self.ros2_storage[0] else "sqlite3"
            args = ["bag", "record", "-s", stg_name,
                    "-b", str(self.cfg["record"]["ros2"]["max_bag_size_bytes"]),
                    "--max-cache-size", str(self.cfg["record"]["ros2"]["max_cache_size_bytes"]),
                    "-o", basename]
            args += topics
            program = "ros2"

        self.session = {
            "ros_ver": self.ros_ver, "scene": scene, "basename": basename,
            "scene_dir": scene_dir, "log_path": log_path,
            "topics": topics, "start_ts": time.time(),
            "program": program, "args": args, "compress": compress,
        }

        self._log("=" * 60)
        self._log("开始录制  场景=%s  ROS=%s" % (scene, self.ros_ver))
        self._log("输出目录：%s" % scene_dir)
        self._log("Topic 数：%d" % len(topics))
        self._log("命令：%s %s" % (program, " ".join(args)))
        self._log("-" * 60)

        self.proc = QProcess(self)
        self.proc.setWorkingDirectory(scene_dir)
        self.proc.setProcessChannelMode(QProcess.MergedChannels)
        self.proc.readyRead.connect(self._on_proc_output)
        self.proc.started.connect(self._on_proc_started)
        self.proc.finished.connect(self._on_proc_finished)
        self.proc.errorOccurred.connect(self._on_proc_error)
        self.proc.start(program, args)

        # 状态更新
        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self._set_params_enabled(False)
        self.lbl_status.setText("● 录制中")
        self.lbl_status.setStyleSheet("color:#d73a49; font-weight:bold;")
        self.stats_timer.start(1000)

    def _on_proc_started(self):
        self._log("[进程已启动 PID=%d]" % self.proc.processId())

    def _on_proc_output(self):
        data = bytes(self.proc.readAll()).decode("utf-8", errors="replace")
        for line in data.splitlines():
            self._log(line)

    def _on_proc_error(self, err):
        self._log("[QProcess 错误] code=%d" % err)

    def _stop_recording(self):
        if self.proc is None:
            return
        self.btn_stop.setEnabled(False)
        self._log("正在停止录制（发送 SIGINT 以正常关闭 bag）…")
        pid = self.proc.processId()
        if pid:
            try:
                os.kill(pid, signal.SIGINT)
            except ProcessLookupError:
                pass
            except Exception as e:
                self._log("[停止异常] %s" % e)
        # 看门狗：20s 未结束则强制 kill
        self.stop_watchdog.start(20000)

    def _force_kill(self):
        if self.proc and self.proc.state() != QProcess.NotRunning:
            self._log("[看门狗] 进程未在 20s 内退出，强制终止。")
            self.proc.kill()

    def _on_proc_finished(self, code, status):
        self.stop_watchdog.stop()
        self.stats_timer.stop()
        self._log("-" * 60)
        self._log("录制结束 exit=%d  用时 %s  写入 %s" % (
            code, self._fmt_elapsed(), self._compute_size_human()))
        self._log("输出目录：%s" % (self.session["scene_dir"] if self.session else ""))
        self._log("=" * 60)
        if self.log_fp:
            try:
                self.log_fp.close()
            except Exception:
                pass
            self.log_fp = None
        # 拷贝 session 供压缩用，然后立即释放 self.session，让用户可马上开始下一次录制
        sess_for_zip = None
        if self.session and self.session.get("compress"):
            sess_for_zip = dict(self.session)
        self.session = None
        self.proc = None
        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self._set_params_enabled(True)
        # 异步启动压缩（不阻塞，不禁用开始按钮）
        if sess_for_zip:
            self._start_zip_compression(sess_for_zip)
        self._update_status_label()
        self._refresh_disks()  # 刷新可用空间

    # ---------------- tar.zst 压缩（录制结束后异步执行） ----------------
    def _start_zip_compression(self, sess):
        """录制结束后，异步启动 tar.zst 压缩进程（不影响下一次录制）。
        sess: 本次录制的 session 副本。
        ROS1: 将多个 .bag 分片文件打包压缩为 <basename>.tar.zst
        ROS2: 将 bag 目录 <basename>/ 打包压缩为 <basename>.tar.zst
        使用 `tar --zstd -cf` 调用 zstd，需系统安装 tar(>=1.31 支持 --zstd) 与 zstd。"""
        sd = sess["scene_dir"]
        base = sess["basename"]
        ros_ver = sess["ros_ver"]
        archive_name = base + ".tar.zst"

        if ros_ver == "ROS1":
            bags = glob.glob(os.path.join(sd, "%s_*.bag" % base))
            if not bags:
                self._log("[压缩] 未找到 .bag 文件，跳过压缩。")
                return
            self._log("[压缩] 开始 tar.zst 压缩：%d 个 .bag 文件 -> %s" % (len(bags), archive_name))
            args = ["--zstd", "-cf", archive_name] + [os.path.basename(b) for b in bags]
        else:  # ROS2: bag 是一个目录
            bag_dir = os.path.join(sd, base)
            if not os.path.isdir(bag_dir):
                self._log("[压缩] 未找到 bag 目录 %s，跳过压缩。" % bag_dir)
                return
            self._log("[压缩] 开始 tar.zst 压缩：bag 目录 %s -> %s" % (base, archive_name))
            args = ["--zstd", "-cf", archive_name, base]

        proc = QProcess(self)
        proc.setWorkingDirectory(sd)
        proc.setProcessChannelMode(QProcess.MergedChannels)
        job = {"proc": proc, "session": sess, "archive_name": archive_name}
        proc.readyRead.connect(self._on_zip_output)
        # 用 lambda 绑定 job，便于回调定位是哪个压缩任务
        proc.finished.connect(lambda code, status, j=job: self._on_zip_finished(code, status, j))
        proc.errorOccurred.connect(lambda err, j=job: self._on_zip_error(err, j))
        self.zip_jobs.append(job)
        proc.start("tar", args)
        self._update_status_label()

    def _on_zip_output(self):
        proc = self.sender()
        data = bytes(proc.readAll()).decode("utf-8", errors="replace")
        for line in data.splitlines():
            if line.strip():
                self._log("[tar.zst] %s" % line.strip())

    def _on_zip_error(self, err, job):
        self._log("[压缩错误] QProcess code=%d" % err)
        if err == QProcess.FailedToStart:
            self._log("[压缩错误] 未找到 tar 命令；或 tar 版本过低不支持 --zstd，"
                       "请安装：sudo apt install tar zstd")

    def _on_zip_finished(self, code, status, job):
        sess = job["session"]
        sd = sess["scene_dir"]
        base = sess["basename"]
        ros_ver = sess["ros_ver"]
        if code == 0:
            self._log("[压缩] tar.zst 压缩完成，删除原 bag 数据。")
            if ros_ver == "ROS1":
                for bag in glob.glob(os.path.join(sd, "%s_*.bag" % base)):
                    try:
                        os.remove(bag)
                    except Exception as e:
                        self._log("[压缩] 删除 %s 失败：%s" % (bag, e))
            else:  # ROS2: 删除 bag 目录
                bag_dir = os.path.join(sd, base)
                try:
                    shutil.rmtree(bag_dir)
                except Exception as e:
                    self._log("[压缩] 删除目录 %s 失败：%s" % (bag_dir, e))
        else:
            self._log("[压缩] tar.zst 压缩失败 exit=%d（原 bag 数据保留）" % code)
        # 从 zip_jobs 移除该任务
        if job in self.zip_jobs:
            self.zip_jobs.remove(job)
        self._update_status_label()
        self._refresh_disks()

    def _update_status_label(self):
        """统一管理状态栏：录制中 > 压缩中 > 空闲"""
        if self.proc is not None:
            self.lbl_status.setText("● 录制中")
            self.lbl_status.setStyleSheet("color:#d73a49; font-weight:bold;")
        elif self.zip_jobs:
            self.lbl_status.setText("● 压缩中(%d)" % len(self.zip_jobs))
            self.lbl_status.setStyleSheet("color:#b58105; font-weight:bold;")
        else:
            self.lbl_status.setText("● 空闲")
            self.lbl_status.setStyleSheet("color:#888; font-weight:bold;")

    def _set_params_enabled(self, on):
        for w in (self.scene_combo, self.disk_combo, self.btn_refresh_disk,
                  self.btn_browse, self.split_spin, self.chk_compress,
                  self.btn_refresh_topic, self.btn_sel_required, self.btn_sel_all,
                  self.btn_sel_none, self.filter_edit, self.topic_list):
            w.setEnabled(on)
        # topic_list 的 enabled 会影响离线项显示，重新使能后恢复正常
        if on:
            self.topic_list.setEnabled(True)

    # ---------------- 统计 ----------------
    def _session_files(self):
        if not self.session:
            return []
        sd = self.session["scene_dir"]
        base = self.session["basename"]
        if self.session["ros_ver"] == "ROS1":
            return glob.glob(os.path.join(sd, "%s_*.bag" % base))
        else:
            d = os.path.join(sd, base)
            if os.path.isdir(d):
                return [os.path.join(d, f) for f in os.listdir(d)]
            return []

    def _compute_size(self):
        return sum(os.path.getsize(f) for f in self._session_files()
                   if os.path.exists(f))

    def _compute_size_human(self):
        return human_size(self._compute_size())

    def _fmt_elapsed(self):
        if not self.session:
            return "00:00:00"
        return self._elapsed_str(int(time.time() - self.session["start_ts"]))

    @staticmethod
    def _elapsed_str(s):
        h, rem = divmod(s, 3600)
        m, s = divmod(rem, 60)
        return "%02d:%02d:%02d" % (h, m, s)

    def _update_stats(self):
        self.lbl_elapsed.setText("已用时：%s" % self._fmt_elapsed())
        self.lbl_written.setText("已写入：%s" % self._compute_size_human())

    # ---------------- 辅助按钮 ----------------
    def _open_data(self):
        mount = self._current_mount()
        if not mount:
            return
        # 录制文件直接放在目标目录下，直接打开 mount
        self._open_path(mount)

    def _open_log(self):
        mount = self._current_mount()
        if not mount:
            return
        if mount == "/" or not is_path_writable(os.path.join(mount, self.cfg["paths"]["logs_dir"])):
            QMessageBox.warning(self, "查看日志",
                "当前目标目录不可写（%s），日志尚未生成。\n请先选择一个可写目录或开始一次录制。" % mount)
            return
        path = os.path.join(mount, self.cfg["paths"]["logs_dir"])
        try:
            os.makedirs(path, exist_ok=True)
        except PermissionError:
            QMessageBox.warning(self, "查看日志", "目录 %s 无写入权限，无法打开日志目录。" % path)
            return
        self._open_path(path)

    def _open_path(self, path):
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    # ---------------- 日志 ----------------
    def _log(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        line = "[%s] %s" % (ts, msg)
        self.log_view.appendPlainText(line)
        if self.log_fp:
            try:
                self.log_fp.write(line + "\n")
                self.log_fp.flush()
            except Exception:
                pass

    # ---------------- 关闭 ----------------
    def closeEvent(self, ev):
        if self.proc is not None:
            reply = QMessageBox.question(
                self, "确认退出", "录制正在进行，退出将停止录制并可能损坏当前 bag。确定退出吗？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply != QMessageBox.Yes:
                ev.ignore()
                return
            self._stop_recording()
            # 给一点时间收尾
            if self.proc and self.proc.state() != QProcess.NotRunning:
                self.proc.waitForFinished(5000)
        if self.zip_jobs:
            reply = QMessageBox.question(
                self, "确认退出", "有 %d 个后台 tar.zst 压缩任务正在进行，退出将中断压缩（原 bag 数据保留）。确定退出吗？"
                % len(self.zip_jobs),
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply != QMessageBox.Yes:
                ev.ignore()
                return
            for job in list(self.zip_jobs):
                job["proc"].kill()
                if job["proc"].state() != QProcess.NotRunning:
                    job["proc"].waitForFinished(3000)
            self.zip_jobs.clear()
        if self.log_fp:
            try:
                self.log_fp.close()
            except Exception:
                pass
        ev.accept()


# =====================================================================
# 入口
# =====================================================================
def main():
    _print_banner()
    # 1) 依赖检测：缺 PyQt5 时引导自动安装（在线国内源 / 离线包）
    if not _HAS_PYQT5:
        print("[ERROR] PyQt5 未安装，尝试自动安装...")
        _bootstrap_deps()
    # 2) 自动 source ROS 系统环境与工作区 install/setup.bash（若需要）
    ensure_ros_env()
    # 3) 图形环境检查（避免无 DISPLAY 时 Qt 静默崩溃）
    if not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY"):
        print("[ERROR] 未检测到图形会话环境（DISPLAY / WAYLAND_DISPLAY 均未设置）。")
        print("        请在桌面终端中运行，或 SSH 远程时使用 'ssh -X' 开启 X11 转发。")
        sys.exit(1)
    # 4) 启动 GUI（用异常钩子捕获 Qt 初始化错误）
    try:
        app = QApplication(sys.argv)
    except Exception as e:
        print("[ERROR] PyQt5 初始化失败: %s" % e)
        print("        可能是图形会话异常或 PyQt5 安装不完整，请重新运行 ./setup_deps.sh install")
        sys.exit(1)
    app.setApplicationName("Record v1.0")
    cfg = load_config()
    try:
        w = MainWindow(cfg)
    except Exception as e:
        print("[ERROR] 主窗口初始化失败: %s" % e)
        import traceback
        traceback.print_exc()
        sys.exit(1)
    w.show()
    print("[INFO] GUI 已启动，等待操作...")
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()

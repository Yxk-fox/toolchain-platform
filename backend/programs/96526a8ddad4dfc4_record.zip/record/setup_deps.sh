#!/bin/bash
# =====================================================================
# 矿区数据采集录制脚本 —— Python 依赖管理工具
# =====================================================================
# 用法:
#   ./setup_deps.sh download   # 在有网络机器上下载所有 wheel 到 packages/(国内源加速)
#   ./setup_deps.sh install    # 安装依赖(先试在线国内源, 无网络则用离线包)
#   ./setup_deps.sh check      # 仅检测依赖是否齐全, 不安装
#   ./setup_deps.sh all        # 检测 + 按需安装(默认)
#
# 依赖清单(必需):  PyQt5>=5.12
# 系统依赖(需 apt 安装):  python3  python3-pip  util-linux(lsblk)  tar(>=1.31)  zstd  ROS1/ROS2 环境
#
# 离线使用流程:
#   1. 在有网络机器(同架构同Python版本)执行:  ./setup_deps.sh download
#   2. 将整个 record/ 目录(含 packages/) 拷贝到离线机器
#   3. 离线机器执行:  ./setup_deps.sh install
# =====================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_DIR="$SCRIPT_DIR/packages"
PY="${PYTHON:-python3}"

# 国内 pip 源(主: 清华 / 备: 阿里)
INDEX_URL="https://pypi.tuna.tsinghua.edu.cn/simple"
INDEX_URL_BACKUP="https://mirrors.aliyun.com/pypi/simple"

# 必需依赖(缺失则无法运行 GUI)
DEPS=(
    "PyQt5>=5.12"
)

# ---------------- 工具函数 ----------------
log()  { echo "[INFO] $*"; }
warn() { echo "[WARN] $*"; }
err()  { echo "[ERROR] $*" >&2; }

detect_python() {
    if ! command -v "$PY" >/dev/null 2>&1; then
        err "未找到 python3，请先安装:  sudo apt install python3 python3-pip"
        return 1
    fi
    log "Python: $($PY --version 2>&1)"
    if ! $PY -m pip --version >/dev/null 2>&1; then
        log "pip 不可用，尝试 bootstrap..."
        if ! $PY -m ensurepip --default-pip >/dev/null 2>&1; then
            err "无法初始化 pip，请执行:  sudo apt install python3-pip"
            return 1
        fi
    fi
}

check_dep() {
    local pkg="$1"
    local mod="${pkg%%[<>=~]*}"
    if $PY -c "import $mod" 2>/dev/null; then
        echo "  [OK]    $mod"
        return 0
    else
        echo "  [MISS]  $mod"
        return 1
    fi
}

check_system_deps() {
    echo "--- 系统命令检测 ---"
    local ok=1
    for cmd in lsblk tar zstd; do
        if command -v "$cmd" >/dev/null 2>&1; then
            echo "  [OK]    $cmd"
        else
            echo "  [MISS]  $cmd  (执行: sudo apt install util-linux tar zstd)"
            ok=0
        fi
    done
    if [ -n "$ROS_DISTRO" ]; then
        echo "  [OK]    ROS($ROS_DISTRO) 已 source"
    else
        echo "  [WARN]  ROS 未 source（脚本运行时会自动尝试 source /opt/ros/<distro>/setup.bash）"
    fi
    if [ -z "$DISPLAY" ] && [ -z "$WAYLAND_DISPLAY" ]; then
        echo "  [WARN]  未检测到图形会话(DISPLAY/WAYLAND_DISPLAY 均未设置)，GUI 可能无法弹出"
        echo "          若在 SSH 远程运行，请使用: ssh -X  或在桌面终端运行"
    else
        echo "  [OK]    图形会话 DISPLAY=${DISPLAY:-$WAYLAND_DISPLAY}"
    fi
    return $ok
}

do_check() {
    echo "===== 依赖检测 ====="
    detect_python || return 1
    check_system_deps || true
    echo "--- Python 依赖检测 ---"
    local missing=0
    for dep in "${DEPS[@]}"; do
        check_dep "$dep" || missing=$((missing+1))
    done
    echo "----------------------"
    if [ "$missing" -eq 0 ]; then
        log "所有 Python 依赖已安装。"
        return 0
    else
        warn "缺少 $missing 个必需依赖。"
        return 1
    fi
}

has_network() {
    curl -sS --connect-timeout 3 -o /dev/null "$INDEX_URL" 2>/dev/null && return 0
    curl -sS --connect-timeout 3 -o /dev/null "$INDEX_URL_BACKUP" 2>/dev/null && return 0
    return 1
}

do_download() {
    echo "===== 下载依赖(国内源加速) ====="
    detect_python || return 1
    mkdir -p "$PKG_DIR"
    log "下载目录: $PKG_DIR"
    log "使用源  : $INDEX_URL (备用: $INDEX_URL_BACKUP)"
    echo ""
    if $PY -m pip download -d "$PKG_DIR" \
            -i "$INDEX_URL" \
            --extra-index-url "$INDEX_URL_BACKUP" \
            "${DEPS[@]}"; then
        log "下载成功(清华源)。"
    else
        warn "清华源下载失败, 尝试阿里源..."
        $PY -m pip download -d "$PKG_DIR" -i "$INDEX_URL_BACKUP" "${DEPS[@]}"
        log "下载成功(阿里源)。"
    fi
    echo ""
    echo "下载文件清单:"
    ls -lh "$PKG_DIR"
    echo ""
    log "下载完成。将整个目录拷贝到离线机器后执行: ./setup_deps.sh install"
}

do_install() {
    echo "===== 安装依赖 ====="
    detect_python || return 1
    if do_check; then
        log "无需安装。"
        return 0
    fi
    echo ""
    if has_network; then
        log "检测到网络, 尝试在线安装(国内源)..."
        if $PY -m pip install -i "$INDEX_URL" \
                --extra-index-url "$INDEX_URL_BACKUP" \
                "${DEPS[@]}"; then
            log "在线安装成功。"
            do_check
            return $?
        fi
        warn "在线安装失败, 尝试离线安装..."
    else
        log "无网络环境, 使用离线包安装..."
    fi
    if [ ! -d "$PKG_DIR" ] || [ -z "$(ls -A "$PKG_DIR" 2>/dev/null)" ]; then
        err "离线包目录 $PKG_DIR 不存在或为空。"
        err "请先在有网络机器执行:  ./setup_deps.sh download"
        return 1
    fi
    log "从 $PKG_DIR 离线安装..."
    $PY -m pip install --no-index --find-links "$PKG_DIR" "${DEPS[@]}"
    do_check
    return $?
}

case "${1:-all}" in
    download) do_download ;;
    install)  do_install ;;
    check)    do_check ;;
    all)
        if do_check; then
            exit 0
        else
            do_install
        fi
        ;;
    -h|--help|help)
        echo "用法: $0 {download|install|check|all}"
        echo ""
        echo "  download  在有网络机器下载依赖 wheel 到 packages/(国内源加速)"
        echo "  install   安装依赖(先试在线国内源, 无网络则用离线包)"
        echo "  check     仅检测依赖是否齐全, 不安装"
        echo "  all       检测 + 按需安装(默认)"
        echo ""
        echo "离线流程: download(联网机) -> 拷贝目录 -> install(离线机)"
        ;;
    *)
        err "未知子命令: $1"
        echo "用法: $0 {download|install|check|all}" >&2
        exit 1
        ;;
esac
